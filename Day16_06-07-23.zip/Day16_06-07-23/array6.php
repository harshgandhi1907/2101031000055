<?php
    $a = 250;
    echo $a;
    echo "<br>";
    echo abs($a);
    echo "<br>";
    echo pow($a,2);
    echo "<br>";
    echo min(32,233);
    echo "<br>";
    $b = 25.428;
    echo ceil($b);
?>