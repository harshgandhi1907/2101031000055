<?php
    $b = array("abc","xyz","pqr");
    print_r($b);
    sort($b);
    echo "<br>"."After Sorting"."<br>";
    print_r($b);
?>