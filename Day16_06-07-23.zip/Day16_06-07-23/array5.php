<?php
    $a = array("xyz"=>12,"abc"=>23);
    print_r($a);
?>