<?php
    // $username = $_POST['username'];
    // $password = $_POST['password'];
    $username = $_GET['username'];
    $password = $_GET['password'];
    echo $username."<br>";
    echo $password;
?>