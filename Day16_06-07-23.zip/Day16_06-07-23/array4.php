<?php
    $a = array("x","y","z","w");
    print_r($a);
    $rev = array_reverse($a);
    echo "<br>";
    print_r($rev);
    echo "<br>";
    echo count($a);
?>