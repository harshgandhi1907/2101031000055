<?php
    $a = "Welcome to php functions";
    echo $a;
    echo "<br>";
    echo strlen($a);
    echo "<br>";
    echo strtoupper($a);
    echo "<br>";
    echo ord($a);
    echo "<br>";
    echo str_replace("o","a",$a);
    echo "<br>";
    echo strrev($a);
    
?>