<?php
    $a = 10;
    $b = 20;

    echo "Value of a is : ".$a;
    echo "<br>";
    echo "Value of b is : ".$b;
    echo "<br>";

    $add = $a + $b;
    echo "Addition is : ".$add;
    echo "<br>";

    $sub = $a - $b;
    echo "Subtraction is : ".$sub;
    echo "<br>";

    $mul = $a * $b;
    echo "Multiplication is : ".$mul;
    echo "<br>";

    $div = $a / $b;
    echo "Divition is : ".$div;
    echo "<br>";
?>