<?php

    $n=13;
    
    if($n%2==0)
    {
        echo $n." is Even Number";
    }
    else{
        
        echo $n." is odd Number";
    }
?>