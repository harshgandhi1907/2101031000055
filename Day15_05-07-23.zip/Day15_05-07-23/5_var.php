<?php
    $a = "123.abc";
    echo "Type of a is : " . gettype($a)."<br>";
    
    settype($a,"int");
    echo "After conversation, Type of a is : " . gettype($a)."<br>";
?>