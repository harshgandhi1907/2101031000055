<?php
    $x = 1;
    $a = 2;
    echo "The table of 2 is : "."<br>";

    while($x <= 10) {
        echo $a ."*". $x ." = " . $a*$x ."<br>";
        $x++;
    }
?>