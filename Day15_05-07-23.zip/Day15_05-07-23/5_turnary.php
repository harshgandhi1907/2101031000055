<?php
    $a = 15;
    $b = 5;
    $c = 12;

    // echo ($a > $b) ? ($a." is greater"):($b." is greater");

    // if($a > $b){
    //     echo $a." is greater";
    // }
    // else{
    //     echo $b." is greater";
    // }

    if($a > $b){
        
        if($a > $c){
        
            echo $a." is greater";
        }
        else{
            echo $c." is greater";
        }
    }
    else{
        if($b > $c){
        
            echo $b." is greater";
        }
        else{
            echo $c." is greater";
        }
    }


?>