<?php
$FirstNumber = 10;
$SecondNumber = 5;
$operator = 1;

switch ($operator) {
case 1:
echo ($FirstNumber + $SecondNumber);
break;
case 2:
 echo  ($FirstNumber - $SecondNumber);
break;
case 3:
echo ( $FirstNumber * $SecondNumber);
break;
case 4:
echo ( $FirstNumber / $SecondNumber);
}

?>