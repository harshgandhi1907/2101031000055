<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <!-- <form action="post.php" id="form1" name="form1" method="post"> -->
    <form action="post.php" id="form1" name="form1" method="post">
        Username:
        <input type="text" name="username" id="username"><hr>
        Password:
        <input type="password" name="password" id="password"><hr>
        <input type="submit" value="Submit" name="submit" id="submit">
    </form>
</body>
</html>