<?php
    $username = "root";
    $servername = "localhost";
    $password = "";
    $dbname = "mydb";
    $conn = mysqli_connect($servername,$username,$password,$dbname);

    if(! $conn){
        die("Connection failed".mysqli_connect_error());
    }

    $sql  = "INSERT INTO info(username,password) VALUES('Harsh','harsh1907'),('Jaival','jaival2512'),('Murtuza','murtuza0109')";
    if(mysqli_query($conn,$sql)){
            echo "Data inserted";
        }
        else{
            echo "error";
    }
?>