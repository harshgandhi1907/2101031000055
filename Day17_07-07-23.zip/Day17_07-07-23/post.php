<?php
    $name = $_POST['username'];
    $pass = $_POST['password'];
    $username = "root";
    $servername = "localhost";
    $password = "";
    $dbname = "mydb";
    $conn = mysqli_connect($servername,$username,$password,$dbname);

    if(! $conn){
        die("Connection failed".mysqli_connect_error());
    }

    $sql  = "INSERT INTO info(username,password) VALUES('$name','$pass')";
    if(mysqli_query($conn,$sql)){
            echo "Data inserted";
        }
        else{
            echo "error";
    }

?>